// код, выполняемый на каждой отедльной веб-странице

var builder = new Builder();
var select_mode = 0; // 0 - selecting elements off, 1 - on
//var host = null;

$(document).ready(function(){
    //host = location.host;
});
 
$(document.body).append(
    '<div id="buttons_div" style="display:none;text-align;center;">\n\
        <button style="width:100%; margin: 5px 0;" id="show_collected_data_button">Show collected data</button>\n\
        <button style="width:100%; margin: 5px 0;" id="switch_select_mode_button">Switch select mode</button>\n\
        <button style="width:100%; margin: 5px 0;">Create builder</button></div>\n\
        <div id="preview_div" style="display:none;">\n\
        <div id="yad2_container_div" style="display:none;">'
);

document.body.onmouseover = function(ev){
    if (!builder.elementExist(builder.getPathTo(ev.target)) && select_mode == 1){
        ev.target.style.boxShadow = "0px 0px 5px red";
    }
};

document.body.onmouseout = function(ev){
    if (!builder.elementExist(builder.getPathTo(ev.target)) && select_mode == 1){
        ev.target.style.boxShadow = "0px 0px 5px white";
    }
};

document.body.onclick = function(ev){
    if (ev.target.id != "show_collected_data_button" && ev.target.id != "switch_select_mode_button" && select_mode == 1){
        switch (location.host) {
            case "www.yad2.co.il": 
                if (location.pathname == "/Nadlan/salesDetails.php"){
                    builder.selectElement(ev.target);
                }
                else{
                    builder.parseYad2Click(ev.target);
                }
                console.log(location.origin)
            break;
            default:
                builder.selectElement(ev.target);
            break;
        }

        ev.preventDefault();
        ev.stopPropagation();
    }
};

$('#buttons_div').show().dialog({
    width: 300,
    height: 200,
    position: { my: "right top", at: "right top", of: window },
    beforeClose: function( event, ui ) {
        $('#buttons_div').hide();
    }
});

$('#show_collected_data_button').click(function(){
    builder.showPreview();
});

$('#switch_select_mode_button').click(function(){
    switchSelectMode();
});

function switchSelectMode(){
    if (select_mode == 1)
        select_mode = 0;
    else select_mode = 1;
}

//builder.inject();