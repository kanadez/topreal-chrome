function Builder(){
    this.selected_elements = [];

    this.showPreview = function(){
        document.getElementById("preview_div").innerHTML = "";
        var string = "<table>";

        for (var i = 0; i < this.selected_elements.length; i++){
            string += "<tr><td>"+this.selected_elements[i][0]+"</td><td>"+this.selected_elements[i][1]+"</td></tr>";
        }

        string += "</table>";

        document.getElementById("preview_div").innerHTML = string;
        $('#preview_div').show().dialog({
            width: 1000,
            height: 500,
            position: { my: "center", at: "center", of: window },
            beforeClose: function( event, ui ) {
                $('#preview_div').hide();
            }
        });
    };
    
    this.getPathTo = function(element) {
        if (element.id !== '')
            return 'id("'+element.id+'")';
        //else if (element.class !== '')
            //return 'class("'+element.class+'")';
        if (element === document.body)
            return element.tagName;

        var ix = 0;
        var siblings = element.parentNode.childNodes;
        for (var i = 0; i < siblings.length; i++){
            var sibling = siblings[i];

            if (sibling === element)
                return this.getPathTo(element.parentNode)+'/'+element.tagName+'['+(ix+1)+']';

            if (sibling.nodeType === 1 && sibling.tagName === element.tagName)
                ix++;
        }
    };

    this.getDataOf = function(element) {
        return element.innerHTML;
    };

    this.elementExist = function(xpath){
        var exist = 0;

        for (var i = 0; i < this.selected_elements.length; i++){
            if (this.selected_elements[i][0] == xpath){
                exist = 1;
            }
        }

        return exist;
    };

    this.deleteElement = function(xpath){
        var tmp_array = [];

        for (var i = 0; i < this.selected_elements.length; i++){
            if (this.selected_elements[i][0] != xpath){
                tmp_array.push(this.selected_elements[i]);
            }
        }

        this.selected_elements = tmp_array;
    };
    
    this.selectElement = function(target){
        if (!this.elementExist(this.getPathTo(target))){
            target.style.boxShadow = "inset 0 0 0 1000px red";
            this.selected_elements.push([this.getPathTo(target), this.getDataOf(target)]);
        }
        else{
            target.style.boxShadow = "0px 0px 5px white";
            this.deleteElement(this.getPathTo(target));
        }
    };
    
    this.parseYad2Click = function(target){
        var parent_tr = $(target).parent();
        //console.log(parent_tr.attr("id").substr(0, 5));
        
        if (parent_tr.attr("id").substr(0, 5) == "tr_Ad"){
            var ad_url = $('#'+parent_tr.attr("id")+' + tr').children().children().children().children('iframe').attr('src');
            //chrome.tabs.create({ url: ad_url });
            chrome.runtime.sendMessage({url: location.origin+ad_url});
        }
        else{
            this.selectElement(target);
        }
    };
}

