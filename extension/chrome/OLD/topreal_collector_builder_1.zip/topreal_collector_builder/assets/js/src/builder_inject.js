//alert(123);
//console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
var selected_elements = [];
        
function getPathTo(element) {
    if (element.id !== '')
        return 'id("'+element.id+'")';
    //else if (element.class !== '')
        //return 'class("'+element.class+'")';
    if (element === document.body)
        return element.tagName;

    var ix = 0;
    var siblings = element.parentNode.childNodes;
    for (var i = 0; i < siblings.length; i++){
        var sibling = siblings[i];

        if (sibling === element)
            return getPathTo(element.parentNode)+'/'+element.tagName+'['+(ix+1)+']';

        if (sibling.nodeType === 1 && sibling.tagName === element.tagName)
            ix++;
    }
}

function getDataOf(element) {
    return element.innerHTML;
}

function elementExist(xpath){
    var exist = 0;

    for (var i = 0; i < selected_elements.length; i++){
        if (selected_elements[i][0] == xpath){
            exist = 1;
        }
    }

    return exist;
}

function deleteElement(xpath){
    var tmp_array = [];

    for (var i = 0; i < selected_elements.length; i++){
        if (selected_elements[i][0] != xpath){
            tmp_array.push(selected_elements[i]);
        }
    }

    selected_elements = tmp_array;
}