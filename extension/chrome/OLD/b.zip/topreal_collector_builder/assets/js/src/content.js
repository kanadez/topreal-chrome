// код, выполняемый на каждой отедльной веб-странице

var builder = new Builder();
var select_mode = 0; // 0 - selecting elements off, 1 - on
$('head').append("<script type='text/javascript' src='//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit'>");
//var host = null;

$(document).ready(function(){
    //window['_mstConfig'].floaterStylePath = '';
    
});
 
$(document.body).append(
    '<div id="buttons_div" style="display:none;text-align;center;">\n\
        <button class="builder_button" id="show_collected_data_button">Show collected data</button>\n\
        <button class="builder_button" id="switch_select_mode_button">Switch select mode</button>\n\
        <button class="builder_button" id="create_builder_button">Create builder</button>\n\
        <div id="MicrosoftTranslatorWidget" class="Dark" style="color:white;background-color:#555555"></div><script type="text/javascript">setTimeout(function(){{var s=document.createElement("script");s.type="text/javascript";s.charset="UTF-8";s.src=((location && location.href && location.href.indexOf("https") == 0)?"https://ssl.microsofttranslator.com":"http://www.microsofttranslator.com")+"/ajax/v3/WidgetV3.ashx?siteData=ueOIGRSKkd965FeEGM5JtQ**&ctf=False&ui=true&settings=Manual&from=";var p=document.getElementsByTagName("head")[0]||document.documentElement;p.insertBefore(s,p.firstChild); }},0);</script>\n\
        <div id="preview_div" style="display:none;"></div>\n\
        <div id="result_div" style="display:none;">Download CSV:<br><a target="_blank" id="download_csv_a" href="">Download</a></div>\n\
        <div id="yad2_container_div" style="display:none;"></div>' 
).css("cursor","default");

document.body.onmouseover = function(ev){
    if (!builder.elementExist(builder.getPathTo(ev.target)) && select_mode == 1){
        ev.target.style.boxShadow = "0px 0px 5px red";
        ev.target.style.background = "white";
    }
    
    if ($(ev.target).attr("translate") == "no" && $(ev.target).attr("id") != "MicrosoftTranslatorWidget"){
        $(ev.target).remove();
    }
};

document.body.onmouseout = function(ev){
    if (!builder.elementExist(builder.getPathTo(ev.target)) && select_mode == 1){
        ev.target.style.boxShadow = "0px 0px 5px white";
    }
};

document.body.onclick = function(ev){
    if (ev.target.id != "show_collected_data_button" && ev.target.id != "switch_select_mode_button" && select_mode == 1){
        switch (location.host) {
            case "www.yad2.co.il": 
                if (location.pathname == "/Nadlan/salesDetails.php"){
                    builder.selectElement(ev.target);
                }
                else{
                    builder.parseYad2Click(ev.target);
                }
                console.log(location.origin)
            break;
            default:
                builder.selectElement(ev.target);
            break;
        }

        ev.preventDefault();
        ev.stopPropagation();
    }
};

$('#buttons_div').show().dialog({
    width: 300,
    height: 250,
    dialogClass: 'buttons_dialog',
    position: { my: "right top", at: "right top", of: window },
    beforeClose: function( event, ui ) {
        $('#buttons_div').hide();
    }
});

$('#show_collected_data_button').click(function(){
    builder.showPreview();
});

$('#switch_select_mode_button').click(function(){
    switchSelectMode();
});

$('#create_builder_button').click(function(){
    builder.exportData();
});

function switchSelectMode(){
    if (select_mode == 1)
        select_mode = 0;
    else select_mode = 1;
}

//builder.inject();