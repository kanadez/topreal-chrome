function Utils(){
    this.isNullOrEmpty = function(value){
        var trimmed = value.trim();
        
        if (trimmed != null && trimmed != "" && trimmed != undefined){
            return false;
        }
        else{
            return true;
        }
    };
    
    this.stringContains = function(string, substring){
        if (string.indexOf(substring) === -1){
            return false;
        }
        else{
            return true;
        }
    };
    
    this.convertTimestampToDate = function(timestamp){
        var a = new Date(timestamp*1000);
        var year = a.getFullYear();
        var month = this.leadZero(a.getMonth()+1,2);
        var date = this.leadZero(a.getDate(), 2);
        var time = date+'/'+month+'/'+ year;

        return time;
    };
    
    this.leadZero = function(number, length) { // используется ф-иями формирования времени для заполнения нулями результат
        while(number.toString().length < length)
            number = '0' + number;
        
        return number;
    };
}