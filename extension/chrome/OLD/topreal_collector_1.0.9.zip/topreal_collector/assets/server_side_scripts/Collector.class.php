<?php

use Database as DB;

class Collector extends DB\TinyMVCDatabaseObject{
    const tablename  = 'collector';
}