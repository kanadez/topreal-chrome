<?php

use Database as DB;

class CollectorLocale extends DB\TinyMVCDatabaseObject{
    const tablename  = 'collector_locale';
}